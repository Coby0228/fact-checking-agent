import os
import json


def count_label_types(folder_path):
    label_count = {
        "true": 0,
        "half-true": 0,
        "false": 0
    }
    # 遍历文件夹中的所有文件
    for filename in os.listdir(folder_path):
        if filename.endswith('.json'):
            file_path = os.path.join(folder_path, filename)
            try:
                # 打开并读取 JSON 文件
                with open(file_path, 'r', encoding='utf-8') as file:
                    data = json.load(file)
                    # 检查是否存在 label 字段
                    if 'label' in data:
                        label = str(data['label']).lower()
                        if label in label_count:
                            label_count[label] += 1
            except Exception as e:
                print(f"Error reading {file_path}: {e}")
    return label_count


if __name__ == "__main__":
    folder_path = 'E:/source_code/agent/dephi/answer2/ExAgent2/dataset/CPMD/'
    result = count_label_types(folder_path)
    print("标签统计结果:")
    for label, count in result.items():
        print(f"{label}: {count}")